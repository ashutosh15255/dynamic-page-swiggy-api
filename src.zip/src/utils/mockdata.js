const resList = [{"title" : "briyani" , "description" : "north cuisine" , "rating" : 4.4},
{title : "dosa" , "description" : "south cuisine" , "rating": 2.4},
    {title : "Andhra Spice" , "description" : "south indian , idli ,dosa" , "rating": 3.4},
    {title : "MacDonalds" , "description" : "pizza, burger , hot dogs" , "rating": 4.6},
    {title : "KFC" , "description" : "pizza burger" , "rating": 3.5},
    {title : "Dominos" , "description" : "pizaa , hot, spicy" , "rating": 2.7},
    {title : "rajshree" , "description" : "south cuisine" , "rating": 1.9},
    {title : "idli centre" , "description" : "south cuisine" , "rating": 4.4},
    {title : "Dosa Centre " , "description" : "south cuisine" , "rating": 2.2},
    {title : "burger king" , "description" : "south cuisine" , "rating": 4.5}];
export default resList;