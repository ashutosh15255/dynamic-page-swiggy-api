import { useEffect } from "react";
import { useState } from "react";
const useRestuarantMenu =(resId)=>{
    const [ResInfo,setResInfo] = useState(null);

    useEffect(()=>{fetchMenu()},[]);
    const fetchMenu = async ()=>{
     const data = await fetch("https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=21.1702401&lng=72.83106070000001&&submitAction=ENTER&restaurantId="+resId);
     const json = await data.json();
     setResInfo(json?.data);
    };
    return ResInfo;
}
export default useRestuarantMenu;