import React from "react";
import ReactDOM from "react-dom/client";
import Header from "./components/Header.js";
import Body from "./components/Body.js";
import RestuarantCard from "./components/RestuarantCard.js";
import { createBrowserRouter,RouterProvider,Outlet} from "react-router-dom";
import About from "./components/About.js";
import Contact from "./components/Contact.js";
import Error from "./components/Error.js";
import RestuarantMenu from "./components/RestuarantMenu.js";

const AppLayout = () => {
    return (
        <div className="app">
            <Header/>
            <Outlet/>
        </div>
    );
};
const appRouter = createBrowserRouter( [{path:'/' , element:<AppLayout />,
children : [
    {
        path:'/' , element : <Body/>, errorElement : <Error/>,
       },{
    path:'/about' , element : <About />, errorElement : <Error/>,
   },
   {
       path:'/contact' , element : <Contact /> , errorElement : <Error/>,
   },
   {
    path:'/restuarant/:resId' , element : <RestuarantMenu /> , errorElement : <Error/>,
}
],
errorElement : <Error/>,},
]);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<RouterProvider router={appRouter}/>);