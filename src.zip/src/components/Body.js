import RestuarantCard from "./RestuarantCard.js";
import resList from "../utils/mockdata.js";
import { useState } from "react";
import { useEffect } from "react";
import Shimmer from "./Shimmer.js";
import { Link } from "react-router-dom";


const Body = () =>{
    const [listofr,setlistofrest] = useState([]);
    const [filteredListt,setfilteredListt] = useState([]);
    const [searchText,setSearchText] = useState("");
    
    useEffect(()=>{fetchData()},[]);
    const fetchData = async() =>{
        const data =await fetch("https://www.swiggy.com/dapi/restaurants/list/v5?lat=12.9351929&lng=77.62448069999999&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING");
    const json = await data.json();

   
  setlistofrest(json?.data?.cards[4]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
 setfilteredListt(json?.data?.cards[4]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
   
    }
    // if(listofr.length===0)
    // {
    //    return <Shimmer/>;
    // }
    // conditional Rendering
    return (listofr.length==0) ? <Shimmer/> : (
        <div className="body">
    
            <div className="filter">
            <div className="search">
            <input type="text" className="search-box" value={searchText} onChange={(e)=>{setSearchText(e.target.value)}}></input>
           
            <button onClick={()=>{
               
                const filteredRest =listofr.filter((res)=>res?.info?.name.includes(searchText));
                    setfilteredListt(filteredRest);
            }}>Search</button>
            </div>

                <button className="filter-btn" onClick={()=>{
                    const filteredlist =listofr.filter((res)=>res?.info?.avgRating > 4.3);
                    setfilteredListt(filteredlist);


                }}>top Rated Restuarant</button>
            </div>
            <div className="res-container"> 
            {filteredListt.map((Restu,key) => (
                <Link key={Restu?.info?.id} to = {'/restuarant/'+Restu?.info?.id}>
                <RestuarantCard  resd={Restu?.info} /></Link>))}
            </div>
        </div>
    );
    };
export default Body;                                                                                                                       