import User from "./User";
import USerClass from "./UserClass";
const About=()=>{
return(
<div>
    <h1>Hello World</h1>
     <h2>this is react by ashutosh</h2>
     <User/>
     <USerClass/>
</div>
);
};
export default About;