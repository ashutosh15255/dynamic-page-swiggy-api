import Shimmer from "./Shimmer";
import { useEffect } from "react";
import { useState } from "react";
import { useParams } from "react-router-dom";
import useRestuarantMenu from "../utils/useRestuarantMenu";
const RestuarantMenu = ()=>{

    const {resId} = useParams();
    const ResInfo = useRestuarantMenu(resId);
   

// const {name, cuisines, costForTwo} = ResInfo?.cards[2]?.card?.card?.info;
//const {itemCards} = ResInfo?.cards[4]?.groupedCard?.cardGroupMap?.REGULAR?.cards;
if(ResInfo === null) return <Shimmer/>;
const {name,cuisines,costForTwo} = (ResInfo?.cards[2]?.card?.card?.info);
const {itemCards}=(ResInfo?.cards[4]?.groupedCard?.cardGroupMap?.REGULAR?.cards[2]?.card?.card);
console.log(itemCards);
        return (
             <div className="menu">
            <h1>{ResInfo?.cards[2]?.card?.card?.info.name}</h1>
            <h2>{ResInfo?.cards[2]?.card?.card?.info.cuisines.join(', ')}</h2>
            <h2>{ResInfo?.cards[2]?.card?.card?.info.costForTwo/100}</h2>
            <ul>
            {itemCards.map((item)=>(<li key={item.card.info.id}> {item.card.info.name}</li>))}
    
            </ul>

        </div>
    );
};
export default RestuarantMenu;