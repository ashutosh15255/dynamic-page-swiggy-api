const RestuarantCard = ({resd}) => {
 
    
    return (
        <div className="res-card" style={{background:"#f0f0f0"}} >
            <img className="res-logo" src ={"https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/"+resd?.cloudinaryImageId}/>
            <h5>{resd?.name}</h5>
            {/* <h3>{resd?.locality}</h3> */}
            <h5>{resd?.areaName}</h5>
            <h5>{resd?.cuisines.join(' , ')}</h5>
            <h6>{resd?.avgRating}</h6>
           
        </div>
    );
};
export default RestuarantCard;