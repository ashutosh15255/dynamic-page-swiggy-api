const User = () =>{
    return(
        <div className="user-card">
            <h1>Name : Ashutosh</h1>
            <h1>Location : Banglore</h1>
            <h1>Contact: abc@gmail.com</h1>
        </div>
    )
}
export default User;